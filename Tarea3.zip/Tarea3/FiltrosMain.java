import java.util.ArrayList;
public class FiltrosMain{
  public static void main(String[] args){
    Filtros f = new Filtros();
    Interfaz in = new Interfaz();
    in.run();
  }
}
