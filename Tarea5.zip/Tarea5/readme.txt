Nombre: LUIS RODRIGO ROJO MORALES
No. Cuenta: 311177903
Correo: rodrigorojo@ciencias.unam.mx

Para correr el código:
$ make
